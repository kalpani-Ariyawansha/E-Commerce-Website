package com.SQA.QATestForShop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QaTestForShopApplication {

	public static void main(String[] args) {
		SpringApplication.run(QaTestForShopApplication.class, args);
	}

}
