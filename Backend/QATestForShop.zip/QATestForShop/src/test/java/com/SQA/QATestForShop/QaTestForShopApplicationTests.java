package com.SQA.QATestForShop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QaTestForShopApplicationTests {

	@Test
	void contextLoads() {
	}

}
